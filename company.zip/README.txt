Yichao Qin
No partner

Type the command given in the project descrption should work. I did not try since I only installed JRE not JDK. But in my IDE it works.
Note that for MyBNApproxInferrence the format is 1000 1 .... .xml ......... First number represents sample size second is the algrorism 
you want to use.1 for rejection 2 for likehoood. I recommand sample size like 10000 which runs not too slow and can avoid exterme probability
when root node has a low probability. 
I am not sure the command "bin" will work in my case.I put all xml under the same folder with src. I use XML reader.
My code works fine and if you have any problem, read my code first.